/* Purpose: follow the criteria of 2.2 from Practical part of Interview process
 * Requirements:
 *  - runs in the background (a thread)
 *  - creates and/or monitors a tmp folder for file content
 *  - archive the first 10 files that eventually appear in tmp folder as file "files.tar.gz"
 *  - after archive file is created, delete all content in tmp folder including tmp folder
 *  - print on console a confirmation message "files collected" before thread is done
 */
package filearchiver;

import java.io.*;
import java.nio.file.*;
import java.util.zip.GZIPOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import org.apache.commons.compress.utils.*;
import org.apache.commons.io.FileUtils;

/**
 *
 * @author zebman95 a.k.a Christopher Wamble (candidate for Canary QA Engineer)
 */
public class FileArchiver implements Runnable {

       // generate the background script 
       public static void main(String args[]) {
           Thread threadFileArchiver = new Thread(new FileArchiver());
           threadFileArchiver.start();
        }

        public void run() {
           // establish tmp directory.  If it does not exist, then create it
           File tmpDir = new File("tmp");
           if(!tmpDir.exists())
                tmpDir.mkdir();

           if(tmpDir.exists()) {        // confirm tmp directory established before preceding
                // monitor the tmp folder for 10 files to appear, check every 2 seconds
                while(fileCount(tmpDir) < 10) {
                   try { Thread.sleep(10000);  } catch(InterruptedException e) { e.printStackTrace();  }
                }
                // create the archive file
                archiveFiles(tmpDir);
                // delete the tmp folder and all its contents
                try { FileUtils.cleanDirectory(tmpDir); } catch(IOException e) { e.printStackTrace(); }
                
                // final step
                System.out.println("files collected");
           }
           
           // file.delete();
        }

        // helper method to create the archive file
        private void archiveFiles(File tmp) {
           TarArchiveOutputStream tarBaseFile = null;
           try {
                FileOutputStream fileOutput = new FileOutputStream("files.tar.gz");
                GZIPOutputStream gzipFile = new GZIPOutputStream(new BufferedOutputStream(fileOutput));
                tarBaseFile = new TarArchiveOutputStream(gzipFile);
                // called to extend the size the compress file can handle
                tarBaseFile.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX);

                // go through list of files in tmp folder and add first 10 to compression file one at a time
                File[] files = fileListing(tmp);
                String filesToCompress = "";
                for(int x=0; x < 10; x++) 
                    addToArchive(files[x], tarBaseFile);
                
           } catch(IOException e) { e.printStackTrace();
           } finally {  // close off the gzip file so it is properly formatted as a functional archive
               try {  tarBaseFile.close(); } catch(IOException e1) { e1.printStackTrace(); }
           }
        }
        
        // helper function to add a file to the compress file being created
        private void addToArchive(File archiveUnit, TarArchiveOutputStream tarBaseFile) throws IOException {

                   tarBaseFile.putArchiveEntry(new TarArchiveEntry(archiveUnit, archiveUnit.getAbsolutePath()));
                   // check if it is a file and simply add it to the compression file
                   if(archiveUnit.isFile()) {  
                        FileInputStream fileInput = new FileInputStream(archiveUnit);
                        BufferedInputStream bufferedFileInput = new BufferedInputStream(fileInput);

                        IOUtils.copy(bufferedFileInput, tarBaseFile);
                        tarBaseFile.closeArchiveEntry();
                        fileInput.close();
              
                   } else if(archiveUnit.isDirectory()) {   // if a directory dive in and add it and its contents to compression file
                        tarBaseFile.closeArchiveEntry();
                        for(File dirFile : fileListing(archiveUnit))
                           addToArchive(dirFile, tarBaseFile);
                   }

        }
        
       // return number of non-hidden files in given directory
        private int fileCount(File dir) {
           return dir.listFiles(new FileFilter() {
                                @Override
                                public boolean accept(File file) { return !file.isHidden(); } }).length;
        }

        // return a file list within given directory of non-hidden files
        private File[] fileListing(File dir) {
           return dir.listFiles(new FileFilter() {
                                @Override
                                public boolean accept(File file) { return !file.isHidden(); } });
        }
    
}
