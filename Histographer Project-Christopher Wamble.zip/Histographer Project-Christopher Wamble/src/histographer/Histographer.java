/*
 * Purpose: using /dev/random generator to generate a histogram of 256 bins.
 * Requirements:
 * - use /dev/random from kernel to generate the random numbers
 * - collect 2000 byte samples as the histogram data
 * - represent histogram in vertical fashion with bins and a "*" per 20 sample frequencies
 */
package histographer;
import java.security.*;
import javax.swing.*;
import java.util.*;
import java.awt.*;
/**
 *
 * @author zebman95 a.k.a Christopher Wamble, candidate for Canary QA Engineer role
 */
public class Histographer {

    /**
     * driver to begin the program
     */
    public static void main(String[] args) {
        // create a histographer and generate the histogram
        Histographer histographer = new Histographer();
        histographer.generateHistogram();
    }

    // used to gather info from the user on the sample size to display
    // then calculate and display the histogram in vertical fashion
    public void generateHistogram() {
        // provide a dropdown selection for sample size
        // through a dialog presented to the user
        Object[] trialChoices = {10,20,30,40,50};
        Integer trials = (Integer) JOptionPane.showInputDialog(null,
                "How many 2000 byte samples do you want to generate?", "Histographer",
                JOptionPane.PLAIN_MESSAGE, null, trialChoices, "Numbers");
        
        // create the /dev/random random number generator
        SecureRandom ranGen1 = null;
        try {  ranGen1 = SecureRandom.getInstance("NativePRNGBlocking", "SUN");
        } catch(NoSuchAlgorithmException e) { e.printStackTrace(); }
          catch(NoSuchProviderException e2) { e2.printStackTrace(); }

        // create the histogram data model
        LinkedHashMap<String,Integer> histogram = new LinkedHashMap<String,Integer>();

        // Based on the sample size select, begin to traverse through the 
        // trials creating the 2000 byte samples
        if(trials != null) {
           int tests = trials.intValue();
           int keyCount = 0;
           int updates = 0;
           while(tests > 0) {
                // create a new sample
                byte[] sample = new byte[2000];
                ranGen1.nextBytes(sample);
                  
                // place the sample data into bins
                for(int x=0; x < sample.length; x++) {
                    Byte sampleData = sample[x];
                   if(histogram.containsKey(sampleData.toString())) // increase frequency of existing bin
                       histogram.put(sampleData.toString(), 1 + histogram.get(sampleData.toString()));
                   else // create new bin
                       histogram.put(sampleData.toString(), 1);
                }
                tests--;  // move on to next new sample
            }            
           
            // display visual representation of the histogram
            displayHistogram(histogram);            
        }
    }
    
    // display visual representation of histogram in vertical fashion   
    public void displayHistogram(LinkedHashMap<String,Integer> histogram) {
        // store the text
        JTextArea displayBoard = new JTextArea();

        // determine the graph output per bin
        int bin = 0;
        for(String key : histogram.keySet()) {
            int frequency = histogram.get(key);
            displayBoard.append(printBin(bin));
            for(int x=0; x < (frequency/20); x++)
                displayBoard.append("*");
            displayBoard.append("\n");
            bin++;
        }

        // generate the visual representation and display it
        JFrame graphView = new JFrame();        
        graphView.add(new JScrollPane(displayBoard, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                    JScrollPane.HORIZONTAL_SCROLLBAR_NEVER));
        graphView.setTitle("Practical Part 2.1: PRNG Histogram");
        
        graphView.setLocation(1500, 75);
        graphView.setSize(new Dimension(400, 800));
        graphView.setVisible(true);
        graphView.setAlwaysOnTop(true);
        
        // stop program once 'x' in visual representation is selected
        graphView.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
    
    // determine how the bin identifier is presented depending upon the bin number
    private String printBin(int bin) {
        String binLabel = "";
        if(bin < 10)
            binLabel = "00"+bin+":";
        else if(bin == 10)
            binLabel = "010:";
        else if(bin > 10 && bin < 100)
            binLabel = "0"+bin+":";
        else
            binLabel = bin+"";

        return binLabel;
    }
}    
